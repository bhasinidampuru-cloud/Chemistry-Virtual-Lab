E-CELL – Virtual Electrochemistry Lab

How to use:
1. Extract this ZIP file.
2. Open index.html in a web browser (Chrome recommended).
3. Use the Galvanic Cell, Nernst Equation, Gibbs Free Energy, Theory and Quiz sections.

This is an educational browser-based simulation. It does not require installation.
